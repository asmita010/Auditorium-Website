Starting with PHPMailer-FE version 4.0.6, we have removed all the
user documentation, changelogs, etc. and put them into one single
area to make documentation updating easier.

You can now find the PHPMailer-ML documentation at our new
knowledgebase website:

http://www.worxware.com/kbn/

More specifically:

PHPMailer-FE Documentation link:
http://www.worxware.com/kbn/?category_id=23

Enjoy!
Andy
