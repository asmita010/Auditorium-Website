<?php

$keyId = 'rzp_test_q943cUDMbO3sG0';
$keySecret = 'Y55xBodQwHHvJKe3w46oL5E6';
$displayCurrency = 'INR';

//These should be commented out in production
// This is for error reporting
// Add it to config.php to report any errors
error_reporting(E_ALL);
ini_set('display_errors', 1);


